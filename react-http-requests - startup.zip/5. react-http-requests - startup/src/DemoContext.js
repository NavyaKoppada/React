import React from 'react';

let DemoContext = React.createContext({
    value: ""
});

export default DemoContext;