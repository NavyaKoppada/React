import Component2 from "./Component2";
import React from 'react';

function Component1(){
    return <>
                <h2>This is Component 1</h2>
                <Component2></Component2>
           </>
}

export default Component1;