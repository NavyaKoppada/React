import './App.css';
import Demo from './Components/Demo/Demo';

function App() {
  return (
    <div className="App">
      <Demo></Demo>
    </div>
  );
}

export default App;
